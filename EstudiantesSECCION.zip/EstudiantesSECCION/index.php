<?php 

  include 'layout/layout.php';
  include 'helper/utility.php';
  

  session_start();
  $_SESSION['estudiant'] = isset($_SESSION['estudiant']) ? $_SESSION['estudiant'] : array();

  $listarEstudiantes = $_SESSION['estudiant'];

  if (!empty($listarEstudiantes)){

    if(isset ($_GET['estudiantesId'])){

        $listarEstudiantes = searchProperty($listarEstudiantes, 'carrera', $_GET['carrreraId']);

    }
  }

?>

<?php 
  PrintHeader();
?>

<main role="main">
      <section class="jumbotron text-center">
        <div class="container">
          <h1 class="jumbotron-heading">Estudadiante</h1>
          <p class="text-muted">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex ad similique aut? 
            Distinctio voluptatibus reiciendis earum facilis totam quisquam cupiditate dolore 
            illum modi necessitatibus delectus excepturi quis voluptates, error deserunt?
            </p>
          <p>
            <a href="Estudiantes/add.php" class="btn btn-primary my-2">AGREGAR NUEVO ESTUDIANTE </a>
          </p>
        </div>
      </section>

      <div class="album py-5 bg-light">
        <div class="container">

          <div style="margin-bottom: 5%;" class="row">
              <div class="cold-md-9"></div>
              <div class="cold-md-3">
                <div class="btn-group">

                  <a href="index.php" class="btn btn-dark text-light">Todos</a>
                  <a href="index.php?carreraId=2" class="btn btn-dark text-light">Redes</a>
                  <a href="index.php?carreraId=3" class="btn btn-dark text-light">Software</a>
                  <a href="index.php?carreraId=4" class="btn btn-dark text-light">Multimedia</a>
                  <a href="index.php?carreraId=5" class="btn btn-dark text-light">Mecatronica</a>
                  <a href="index.php?carreraId=6" class="btn btn-dark text-light">Seguridad Informatica</a>
                
                </div>
              </div>
            </div>

          <div class="row">

          <?php if(empty($listarEstudiantes)): ?>
            
              <h2>No Hay Estudiantes Regristrados, Agregar Estudiante aqui: <a href="Estudiantes/add.php" class='btn btn-primary' >
                  Nuevo Estudiante</a> 
              </h2>

          <?php else: ?>
          
          <?php foreach ($listarEstudiantes as $estudiante): ?>

            <div style="margin-bottom: 3%;"  class="col-md-4">
              <div class="card" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title"> <?php echo $estudiante['name']; ?></h5>
                  <h5 class="card-title"> <?php  echo $estudiante['apellido']; ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo getEstado($estudiante['estado']); ?></h6>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo getCarrera($estudiante['carrera']); ?></h6>
                    <a href="Estudiantes/edit.php?id=<?php echo $estudiante ['id']?>" class="card-link">Editar</a>
                    <a href="Estudiantes/delete.php?id=<?php echo $estudiante ['id']?>" class="card-link">Borrar</a>
                </div>
              </div>
            </div>

          <?php endforeach; ?>

          <?php endif; ?>

          </div>
        </div>
      </div>

    </main>

<?php 
  PrintFooter();
?>
