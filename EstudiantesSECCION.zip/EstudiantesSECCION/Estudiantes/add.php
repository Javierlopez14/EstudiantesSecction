<?php 

  include '../layout/layout.php';
  include '../helper/utility.php';

  session_start();

  if(isset($_POST['nombre']) && isset($_POST['apellido']) && 
     isset($_POST['estado']) && isset($_POST['carrera']) ){

        $_SESSION['estudiant'] = isset($_SESSION['estudiant']) ? $_SESSION['estudiant'] : array();

        $estudiantes = $_SESSION['estudiant'];

        $estudianteId = 1;

        if (!empty($estudiantes)){
            $lastElement = getLastElement(estudiantes);
            $estudianteId = lastElement['id'] + 1;
        }

        array_push($estudiantes, ['id' => $estudianteId, 'name' => $_POST['nombre'], 'apellido' => $_POST['apellido'], 
                                  'estado' => $_POST['estado'], 'carrera' => $_POST['carrera']]);
        
        $_SESSION['estudiant'] = $estudiantes;
        
        header("Location: ../index.php");
        exit();
  }

?>


<?php 
  PrintHeader(true);
?>

<main role="main">
   
    <div style="margin-top: 2%;" class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center bg-dark text-light">
                    <h4>AGREGAR NUEVO ESTUDIANTE</h4>
                    <a href="../index.php" class="btn btn-warning">Volver Atras</a>
                </div>
            <div class="card-body">

                <form action="add.php" method="POST">

                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" class="form-control" placeholder="Nombre" name="nombre">
                    </div>

                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input type="text" class="form-control" placeholder="Apellido" name="apellido">
                    </div>



                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select name="estado" id="estado" class="form-control">
                            <?php foreach($estado as $id => $text): ?> 

                                <option value="<?php echo $id;?>"> <?php echo $text;?> </option>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="carrera">Carrera</label>
                        <select name="carrera" class="form-control" id="carrera">
                            <?php foreach($carrera as $id => $text): ?>  

                                <option value="<?php echo $id;?>"> <?php echo $text;?> </option>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success" > Guardar </button>

                </form>
                
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</main>

<?php 
  PrintFooter(true);
?>