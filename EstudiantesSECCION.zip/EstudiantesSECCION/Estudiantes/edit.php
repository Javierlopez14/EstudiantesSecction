<?php 

  include '../layout/layout.php';
  include '../helper/utility.php';

  session_start();
  

  if(isset($_GET['id'])){

    $estudianteeId = $_GET['id'];

    $_SESSION['estudiant'] = isset($_SESSION['estudiant']) ? $_SESSION['estudiant'] : array();

        $estudiantes = $_SESSION['estudiant'];

    $element = searchProperty($estudiantes, 'id', $estudianteeId)[0];
    $elementIndex = getIndexElement($estudiantes, 'id', $estudianteeId);

    if(isset($_POST['nombre']) && isset($_POST['apellido']) && 
     isset($_POST['estado']) && isset($_POST['carrera']) ){


        $updateEstudiante = ['id' => $estudianteId, 'name' => $_POST['nombre'], 'apellido' => $_POST['apellido'], 
                                  'estado' => $_POST['estado'], 'carrera' => $_POST['carrera']];

        $estudiantes[$elementIndex] = $updateEstudiante;
        
        $_SESSION['estudiant'] = $estudiantes;
        
        header("Location: ../index.php");
        exit();
  }

  }
  else {
    header("Location: ../index.php");
    exit();
  }


?>


<?php 
  PrintHeader(true);
?>

<main role="main">
   
    <div style="margin-top: 2%;" class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center bg-dark text-light">
                    <h4>AGREGAR NUEVO ESTUDIANTE</h4>
                    <a href="../index.php" class="btn btn-warning">Volver Atras</a>
                </div>
            <div class="card-body">

                <form action="edit.php?id=<?php echo $element['id']?>" method="POST">

                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" value="<?php echo $element['name'] ?>" class="form-control" placeholder="Nombre" name="nombre">
                    </div>

                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input type="text" value="<?php echo $element['apellido'] ?>" class="form-control" placeholder="Apellido" name="apellido">
                    </div>



                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select name="estado" id="estado" class="form-control">
                            <?php foreach($estado as $id => $text): ?> 

                                <?php if($id == $element['estado']): ?>

                                    <option selected value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php else :?>

                                    <option value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php endif;?>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="carrera">Carrera</label>
                        <select name="carrera" class="form-control" id="carrera">
                            <?php foreach($carrera as $id => $text): ?>  

                                <?php if($id == $element['carrera']): ?>

                                    <option selected value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php else :?>

                                    <option value="<?php echo $id;?>"> <?php echo $text;?> </option>

                                <?php endif;?>
                                
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success" > Guardar </button>

                </form>
                
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</main>

<?php 
  PrintFooter(true);
?>