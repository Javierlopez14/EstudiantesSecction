<?php

include '../helper/utility.php';

session_start();

$estudiantes = $_SESSION['estudiant'];

if(isset($_GET['id'])){

    $estudianteId = $_GET['id'];

    $elementIndex = getIndexElement($estudiantes, 'id', $estudianteId);

    unset($estudiantes[$elementIndex]);

    $_SESSION['estudiant'] = $estudiantes;

}

header("Location: ../index.php");
exit();

?>