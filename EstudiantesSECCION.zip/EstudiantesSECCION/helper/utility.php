<?php 

    $estado = [1 => "Activo", 2 =>"Inactivo"];

    $carrera = [1=> "Selecione una Carrera",2 => 'Redes',3 => "Software",4 => "Multimedia",
                5 => "Mecatronica",6 => "Seguridad Informatica"];

    function getLastElement($list){
        $countList = count($list);
        $lastElement = $list[$counList - 1];

        return lastElement;
    }

    function getEstado($estadoId){
        return $GLOBALS['estado'][$estadoId];
    }

    function getCarrera($carreraId){
        return $GLOBALS['carrera'][$carreraId];
    }

    function searchProperty($list, $property, $value){
        $filter = [];

        foreach($list as $item){
            if($item[$property] == $value){
                array_push($filter, $item);
            }
        }

        return $filter;
    }

    function getIndexElement($list, $property, $value){
        $index = 0;

        foreach($list as $key => $item){
            if($item[$property] == $value){
               $index = $key;
            }
        }

        return $index;
    }

?>